// next.config.ts
const nextConfig = {
  output: 'export', // Netlify에서 정적 사이트를 호스팅할 수 있도록 설정
};

export default nextConfig;

